# RPcovidActiveLearning
## Active Learning Algorithm for MNIST